import React, { useState } from 'react';
import { View, TextInput, Button, FlatList, Text, StyleSheet } from 'react-native';

const App = () => {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [course, setCourse] = useState('');
  const [price, setPrice] = useState('');
  const [menuItems, setMenuItems] = useState([]);

  const addMenuItem = () => {
    if (name && description && course && price) {
      const newItem = { name, description, course, price: parseFloat(price) };
      setMenuItems([...menuItems, newItem]);
      // Reset input fields
      setName('');
      setDescription('');
      setCourse('');
      setPrice('');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Dish Name" value={name} onChangeText={setName} />
      <TextInput placeholder="Description" value={description} onChangeText={setDescription} />
      <TextInput placeholder="Course" value={course} onChangeText={setCourse} />
      <TextInput placeholder="Price" value={price} onChangeText={setPrice} keyboardType="numeric" />
      <Button title="Add Menu Item" onPress={addMenuItem} />
      <Text>Total Menu Items: {menuItems.length}</Text>
      <FlatList
        data={menuItems}
        keyExtractor={(item) => item.name}
        renderItem={({ item }) => (
          <Text>{`${item.name} - ${item.description} (${item.course}): $${item.price}`}</Text>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 91,
  },
});

export default App;
